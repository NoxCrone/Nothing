import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function AboutScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.contentContainer}>
        <Text style={styles.titleText}>About Nothing</Text>
        <Text style={styles.descriptionText}>
          An app about embracing minimalism and emptiness.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  titleText: {
    fontSize: 22,
    fontWeight: '500',
    color: '#000000',
    marginBottom: 16,
  },
  descriptionText: {
    fontSize: 16,
    fontWeight: '300',
    color: '#222222',
    textAlign: 'center',
    lineHeight: 24,
  },
});